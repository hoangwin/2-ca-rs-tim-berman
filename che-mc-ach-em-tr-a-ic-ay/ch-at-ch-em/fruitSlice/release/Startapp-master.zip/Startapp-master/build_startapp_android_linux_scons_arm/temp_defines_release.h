#ifndef ANDROID
#   define ANDROID 1
#endif
#ifndef I3D_ARCH_ARM
#   define I3D_ARCH_ARM 1
#endif
#ifndef I3D_OS_LINUX
#   define I3D_OS_LINUX 1
#endif
#ifndef I3D_PLATFORM_LINUX
#   define I3D_PLATFORM_LINUX 1
#endif
#ifndef IW_ASSERTION_CHANNEL_STARTAPP
#   define IW_ASSERTION_CHANNEL_STARTAPP 1
#endif
#ifndef IW_MKF_EDK
#   define IW_MKF_EDK 1
#endif
#ifndef IW_MKF_STARTAPP_BUILD
#   define IW_MKF_STARTAPP_BUILD 1
#endif
#ifndef IW_PLATFORM_LINUX
#   define IW_PLATFORM_LINUX 1
#endif
#ifndef IW_SDK
#   define IW_SDK 1
#endif
#ifndef IW_TRACE_CHANNEL_STARTAPP
#   define IW_TRACE_CHANNEL_STARTAPP 1
#endif
#ifndef IW_TRACE_CHANNEL_STARTAPP_VERBOSE
#   define IW_TRACE_CHANNEL_STARTAPP_VERBOSE 2
#endif
#ifndef S3E_ANDROID
#   define S3E_ANDROID 1
#endif
#ifndef S3E_BUILD_EXT
#   define S3E_BUILD_EXT 1
#endif
#ifndef S3E_EXT_STARTAPP
#   define S3E_EXT_STARTAPP 1
#endif
