This is a working example under Marmalade 6.1.2.
Just copy everything in the HelloWorld folder you should have in C:\Marmalade\6.1\examples