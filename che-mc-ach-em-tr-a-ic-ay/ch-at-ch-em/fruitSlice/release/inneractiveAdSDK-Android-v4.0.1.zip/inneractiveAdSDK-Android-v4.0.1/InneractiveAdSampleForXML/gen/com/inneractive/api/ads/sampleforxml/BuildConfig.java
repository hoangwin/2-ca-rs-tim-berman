/** Automatically generated file. DO NOT MODIFY */
package com.inneractive.api.ads.sampleforxml;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}